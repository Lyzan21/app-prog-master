package hska.de.appprogramming.listeners;

import hska.de.appprogramming.model.Offer;

/**
 * Created by Alina on 15.05.2018.
 */

public interface MyItemClickListener {
    void onItemClick(Offer item);
}
